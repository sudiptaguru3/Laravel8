<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<form action="sendtxtmail" method="get">
		<input type="text" name="title">
		<input type="text" name="body">
		<button type="submit">Submit</button>
	</form>
</body>
</html><?php /**PATH C:\xampp\htdocs\example-app\resources\views/mail.blade.php ENDPATH**/ ?>