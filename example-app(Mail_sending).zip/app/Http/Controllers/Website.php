<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Mail;
class Website extends Controller
{
    public function index(){
        // echo "Hello";
        $data=['name'=>"Sudipta",'data'=>"Hello"];
        $user['to']='sudiptaguru74@gmail.com';
        Mail::send('mail',$data,function($messages) use ($user){
            $messages->to('sudiptaguru74@gmail.com');
            $messages->subject('Hello');
        });
    }
}
