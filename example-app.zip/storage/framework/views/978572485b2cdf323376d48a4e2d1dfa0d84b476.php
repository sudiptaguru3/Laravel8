<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Sudipta Guru\Desktop\Sudipta Guru\example-app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>