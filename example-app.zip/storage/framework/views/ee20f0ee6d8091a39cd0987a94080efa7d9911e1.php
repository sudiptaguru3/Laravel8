<?php echo e($slot); ?>

<?php /**PATH C:\Users\Sudipta Guru\Desktop\Sudipta Guru\example-app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>