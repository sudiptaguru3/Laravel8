<table>
    @foreach ($data as $item)
    <tr>
        <td>{{$item->title}}</td>
        <td>{{$item->country_name}}</td>
        <td>{{$item->state_name}}</td>
        <td>{{$item->city_name}}</td>
    </tr>
    @endforeach
</table>