<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Device;
use App\Models\Product;
class ProductController extends Controller
{
    //
    function list()
    {
    	// return Device::all();
    	return Product::all();
    }
}
