<?php

namespace App\Http\Controllers;
use App\Models\Member;
use Illuminate\Http\Request;
Use \Carbon\Carbon;
class MemberController extends Controller
{
    function addData(Request $req)
    {
    	$member=new Member;
    	$member->name=$req->name;
    	$member->email=$req->email;
    	date_default_timezone_set('Asia/Kolkata');//or choose your location
    	$member->created_at=Carbon::now();
    	$member->save();
    }
}
