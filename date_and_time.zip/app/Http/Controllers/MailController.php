<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Mail\MyTestMail;
class MailController extends Controller
{
    public function sendEmail()
    {
    	$details=[
    		'title'=>'Mail from surfside',
    		'body'=>'hello'
    	];
    	Mail::to('sudiptaguru74@gmail.com')->send(new MyTestMail($details));
    	return "Mail sent";
    }
}
