<h1>
	Upload file
</h1>
<form action="upload" method="POST" enctype="multipart/form-data">
	<?php echo csrf_field(); ?>
	<input type="file" name="file" ><br><br>
	<button type="submit">Upload file</button>
</form><?php /**PATH C:\xampp\htdocs\8\blogs\resources\views/upload.blade.php ENDPATH**/ ?>