<h1>Add new member</h1>
<form action="storecontroller" method="POST">
	<?php echo csrf_field(); ?>
	<input type="text" name="user" placeholder="Enter User Name"><br><br>
	<input type="password" name="password" placeholder="Enter User Password"><br><br>
    <input type="text" name="email" placeholder="Enter User Email"><br><br>
    <button type="submit">Add User</button>
</form><?php /**PATH C:\xampp\htdocs\8\blogs\resources\views/storeuser.blade.php ENDPATH**/ ?>