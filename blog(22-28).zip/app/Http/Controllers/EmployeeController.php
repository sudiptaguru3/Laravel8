<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class EmployeeController extends Controller
{
    //
    function getData()
    {
    	// return "hello from controller";
    	// return DB::table('employee')
        $data= DB::table('employee')
    	->join('members','employee.id','=','members.emp_id')
    	// ->select('members.*','employee.*')
    	// ->where('employee.name','Ram')
    	// ->where('employee.id',1)
    	// ->select('employee.name','members.name')
        ->get();
        return view('list',['data'=>$data]);
        $data1= DB::table('members')->sum('id');
        return view('list',['data'=>$data1]);
    }
}
