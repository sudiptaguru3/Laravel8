<table border="1">
	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($item->id); ?></td>
		<td><?php echo e($item->name); ?></td>
		<td><?php echo e($item->address); ?></td>
		<td><?php echo e($item->email); ?></td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<l>hhg</l>
<?php /**PATH C:\Users\Sudipta Guru\Desktop\Sudipta Guru\blog\resources\views/list.blade.php ENDPATH**/ ?>