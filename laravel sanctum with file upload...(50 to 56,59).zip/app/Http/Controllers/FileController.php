<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FileController extends Controller
{
    //
    // function upload()
    function upload(Request $req)
    {
    	// return "Hello from controller";
    	// return $req->file('file')->store('apiDocs');
    	$result = $req->file('file')->store('apiDocs');
    	return ['result'=>$result];
    }
}
