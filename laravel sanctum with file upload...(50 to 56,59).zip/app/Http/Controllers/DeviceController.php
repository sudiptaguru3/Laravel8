<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Device;
use Validator;
class DeviceController extends Controller
{
    //
    function add(Request $req)
    {
    	$device = new Device;
    	$device->name=$req->name;
    	$device->member_id=$req->member_id;
    	$result=$device->save();
    	if($result)
    	{
    		return ["result"=>"Data hasbeen saved"];
    		// return ["result"=>"done"];
    	}
    	else
    	{
    		return ["result"=>"Operation failed"];
    	}
    }
    function update(Request $req)
    {
        $device = Device::find($req->id);
        $device->name=$req->name; 
        $device->member_id=$req->member_id;
        $result=$device->save();
        if($result)
        {
            return ["result"=>"Data hasbeen updated"];
            // return ["result"=>"done"];
        }
        else
        {
            return ["result"=>"Operation failed"];
        }
    }
    function delete($id)
    {
        $device = Device::find($id);
        $result=$device->delete();
        if($result)
        {
            return ["result"=>"Data hasbeen deleteed"];
            // return ["result"=>"done"];
        }
        else
        {
            return ["result"=>"Operation failed"];
        }
    }
    function search($name)
    {
        // return Device::where("name",$name)->get();
        return Device::where("name", "like", "%".$name."%")->get();
    }
    function testData(Request $req)
    {
        $rules=array(
            "member_id"=>"required | max:4",
            "name"=>"required"
        );
        $validator=validator::make($req->all(),$rules);
        if($validator->fails())
        {
            // return $validator->errors();
            return response()->json($validator->errors(),401);
        }
        else
        {
            // return ["a"=>"x"];
            $device = new Device;
            $device->name=$req->name;
            $device->member_id=$req->member_id;
            $result=$device->save();
            if($result)
        {
            return ["result"=>"Data hasbeen saved"];
            // return ["result"=>"done"];
        }
        else
        {
            return ["result"=>"Operation failed"];
        }
        }
    }
}
