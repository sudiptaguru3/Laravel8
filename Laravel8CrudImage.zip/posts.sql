-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 10, 2021 at 06:37 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blogdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `image`, `description`, `country`, `state`, `city`, `created_at`, `updated_at`) VALUES
(1, 'ygygy', 'public/images/93aGHHaZDSP7qu3plTP8ggqdwLugb0Cs1rz4OaNq.jpg', 'c cv c', '', '', '', '2021-08-09 09:55:05', '2021-08-09 09:55:05'),
(2, 'ygygy', 'public/images/uFrswYfiIlmMpmwmlw4Mo11wwc6PfvUnr0IJh49V.jpg', 'kikm', '', '', '', '2021-08-09 11:58:49', '2021-08-09 11:58:49'),
(3, 'iujhu', 'public/images/g31n7eBWG1yiYExunDsPDngs6D5Q0ewm1OAWadhK.jpg', 'gtfvgv', '2', '4', '8', '2021-08-09 11:59:04', '2021-08-10 04:34:02'),
(4, 'ygygy', 'public/images/nfL3QmPcSGMDGryhu3ww2dIfxwzGNp7fjmItWhDf.jpg', 'uhbh', 'ABC', '', '', '2021-08-10 02:28:33', '2021-08-10 02:28:33'),
(5, 'ygygy', 'public/images/YUwJeAGGn4gVgzKDj8lDUAUCjuM3x07fOLjkA02a.jpg', 'c vcvdcvd', '2', '4', '8', '2021-08-10 04:03:11', '2021-08-10 04:40:00'),
(6, 'ygygy', 'public/images/8aSBZVpsLteIgyqx8B2hRzTuboPBOMsba0fSOc3Q.jpg', 'ygyg', '2', '4', '8', '2021-08-10 04:32:41', '2021-08-10 04:32:41');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
