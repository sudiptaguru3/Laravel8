<l><?php echo e($data1); ?></l><br>
<l><?php echo e($data2); ?></l>
<table class="table table-bordered">
        <tr>
            <th>S.No</th>
            <th>Image</th>
            <th>Title</th>
            <th>Description</th>
            <th width="280px">Action</th>
        </tr>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($post->id); ?></td>
            <td><img src="<?php echo e(Storage::url($post->image)); ?>" height="75" width="75" alt="" /></td>
            <td><?php echo e($post->title); ?></td>
            <td><?php echo e($post->description); ?></td>
            <td>
                <form action="<?php echo e(route('posts.destroy',$post->id)); ?>" method="POST">
    
                    <a class="btn btn-primary" href="<?php echo e(route('posts.edit',$post->id)); ?>">Edit</a>
   
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
      
                    <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this item ?');">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  <?php /**PATH C:\Users\Sudipta Guru\Desktop\Sudipta Guru\test\Laravel8CrudImage\resources\views/posts/index1.blade.php ENDPATH**/ ?>