<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\str;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
$info="hi. let's learn laravel";
// $info=Str::ucfirst($info);
// $info=Str::replaceFirst("Hi","Hello",$info);
// $info=Str::Camel($info);
$info=Str::of($info)->ucfirst($info)->replaceFirst("Hi","Hello",$info)->Camel($info);
echo $info;
// echo "hello";
Route::get('/', function () {
    return view('welcome');
});
