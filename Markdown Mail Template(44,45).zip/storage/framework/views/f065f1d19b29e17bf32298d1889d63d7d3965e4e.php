<?php echo e($slot); ?>

<?php /**PATH C:\Users\Sudipta Guru\Desktop\Sudipta Guru\blog\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>