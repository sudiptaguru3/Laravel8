<h1>User Login</h1>
<form action="users" method="POST">
	<?php echo csrf_field(); ?>
	<?php echo e(method_field('PUT')); ?>

	<input type="text" name="user" placeholder="Enter User name" /><br><br>
	<input type="password" name="password" placeholder="Enter User password" /><br><br>
	<button>Login</button>
</form><?php /**PATH C:\Users\Sudipta Guru\Desktop\Sudipta Guru\blog\resources\views/users.blade.php ENDPATH**/ ?>