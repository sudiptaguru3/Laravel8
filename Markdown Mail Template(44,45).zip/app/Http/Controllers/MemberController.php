<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Member;
class MemberController extends Controller
{
    //
    function index(Member $key)
    {
        return $key->all();
        // return Member::all();
        // return "hello from MemberController";
        // return Member::find(1)->companyData();
        // $member=new Member;
        // $member->name="Shyam";
        // $member->email="Shyam@m.com";
        // $member->address="Kolkata";
        // $member->emp_id="2";
        // $member->save();
    }
    function addData(Request $req)
    {
    	$member=new Member;
    	$member->name=$req->name;
    	$member->email=$req->email;
    	$member->save();
    }
    function show()
    {
    	// return "hello from MemberController";
    	// return view('list');
    	// return Member::all();
    	$data=Member::all();
    	return view('list',['members'=>$data]);
    }
}
