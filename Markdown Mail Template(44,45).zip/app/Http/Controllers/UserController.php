<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
class UserController extends Controller
{
    //
    function getData()
    {
    	return User::all();
    }
    
    function testRequest(Request $req)
	{
		return $req->input();
	}
}
