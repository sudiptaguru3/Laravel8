<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Member extends Model
{
    use HasFactory;
    public $timestamps=false;
    // return redirect('add');
    // function getNameAttribute($value)
    // {
	   //  return ucFirst($value);
    // }
    // function getAddressAttribute($value)
    // {
    // 	return $value.", India";
    // }
    function companyData()
    {
    	return $this->hasOne('App\Models\Company');
    }
    function setNameAttributes($value)
    {
	    return $this->attribute['name']= 'Mr '.$value;
    }
    function setAddressAttributes($value)
    {
    	return $this->attribute['address']= $value.", India";
    }
}


