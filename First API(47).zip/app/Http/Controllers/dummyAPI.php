<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class dummyAPI extends Controller
{
    //
    function getData()
    {
    	return ["name"=>"Sudipta","email"=>"sudiptagru3@gmail.com"];
    }
}
