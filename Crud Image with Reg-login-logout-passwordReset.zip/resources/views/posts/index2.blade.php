<table>
	@foreach ($posts as $post)
	<tr>
		<td>{{ $i1++ }}</td>
	</tr>
	@endforeach
</table>
 {!! $posts->links() !!}