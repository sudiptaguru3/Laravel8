<h1>Member List</h1>
<table border="1">
	<tr>
		<th>ID</th>
		<th>Name</th>
		<th>Email</th>
	</tr>
	<?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($member['id']); ?></td>
		<td><?php echo e($member['name']); ?></td>
		<td><?php echo e($member['email']); ?></td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH C:\Users\Sudipta Guru\Desktop\Sudipta Guru\blog\resources\views/list.blade.php ENDPATH**/ ?>