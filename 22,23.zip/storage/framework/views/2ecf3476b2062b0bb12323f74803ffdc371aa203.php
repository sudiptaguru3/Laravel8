<h1>Add Members</h1>
<form action="add" method="POST">
	<?php echo csrf_field(); ?>
	<input type="text" name="name" placeholder="Enter Name"><br><br>
	<input type="text" name="email" placeholder="Enter Email"><br><br>
	<button type="submit">Add Member</button>
</form><?php /**PATH C:\Users\Sudipta Guru\Desktop\Sudipta Guru\blog\resources\views/addmember.blade.php ENDPATH**/ ?>