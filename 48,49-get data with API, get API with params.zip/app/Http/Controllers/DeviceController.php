<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Device;
class DeviceController extends Controller
{
    //
    // function list ()
    // function list ($id)
    function list ($id=null)
    {
    	// return Device::all();
    	// return Device::find($id);
    	return $id?Device::find($id):Device::all();
    }
    // function list ($id=null)
    // {
    // 	// return Device::all();
    // 	return $id?Device::find($id):Device::all();
    // }
}
