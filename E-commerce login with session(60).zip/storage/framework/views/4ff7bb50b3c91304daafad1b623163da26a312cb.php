<form action="login" method="POST">
    <div class="form-group">
        <?php echo csrf_field(); ?>
<label>Email Address</label><input type="email" class="form-control" name="email"><br><br>
<label>Password</label><input type="password" class="form-control" name="password">
</div><br>
<input type="submit" name="">
</form><?php /**PATH C:\Users\Sudipta Guru\Desktop\Sudipta\L81\blogs\resources\views/login.blade.php ENDPATH**/ ?>