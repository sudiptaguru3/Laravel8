<?php $__env->startSection("content"); ?>
<div class="container custom-login">
    <div class="row">
        <div class="col-sm-4 col-sm-offset-4">
<form action="/login" method="POST">
    <div class="form-group">
        <?php echo csrf_field(); ?>
<label for="exampleInputEmail">Email Address</label><input type="email" class="form-control" id="exampleInputEmail" name="email"></div>
<label for="exampleInputPassword">Password</label><input type="password" class="form-control" id="exampleInputPassword" name="name">
</div>
<button type="submit" class="btn btn-default" name="">Login</button>
</form>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sudipta Guru\Desktop\Sudipta\L81\blogs\resources\views/welcome.blade.php ENDPATH**/ ?>