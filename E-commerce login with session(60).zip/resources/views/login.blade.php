<form action="login" method="POST">
    <div class="form-group">
        @csrf
<label>Email Address</label><input type="email" class="form-control" name="email"><br><br>
<label>Password</label><input type="password" class="form-control" name="password">
</div><br>
<input type="submit" name="">
</form>