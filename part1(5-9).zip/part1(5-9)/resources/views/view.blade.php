<h1>Hello {{$user}}</h1>
<h1>Hello {{$name}}</h1>
<h1>{{10*20}}</h1>
<h1>Hello, {{$users}}</h1>
<h1>Hello, {{count($names)}}</h1>
<h1>Hello, {{$name}}</h1>
<x-header />