<div>
	<h1>Header Component</h1>
    <!-- Smile, breathe, and go slowly. - Thich Nhat Hanh -->
</div>