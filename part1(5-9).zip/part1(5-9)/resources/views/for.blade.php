<h1>Users Page</h1>
@for($i=0;$i<10;$i++)
<h4>{{$i}}</h4>
@endfor