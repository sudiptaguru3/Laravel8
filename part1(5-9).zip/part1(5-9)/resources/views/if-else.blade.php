<h1>Users Page</h1>

@if($name=='Sudipta')
<h2>Hi, {{$name}}</h2>
@elseif($name=='Sudip')
<h2>Hi, {{$name}}</h2>
@else
<h2>Hi, Unknown</h2>
@endif
