<h1>Users Page</h1>
@foreach ($users as $user)
<h3>{{$user}}</h3>
@endforeach