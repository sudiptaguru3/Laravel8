<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UsersController extends Controller
{
    //
    // function loadView()
    // {
    // 	return view('users');
    // }
    // function loadView($user)
    // {
    // 	return view('users',['name'=>$user]);
    // }
    // function loadView()
    // {
    // 	return view('users',['users'=>'Sudipta']);
    // }
    // function loadView()
    // {
    // 	return view('users',['names'=>['Sudipta','Sudip']]);
    // }
    // function loadView()
    // {
    // 	return view('users',['name'=>'Sudipta']);
    // }
    function loadView()
    {
    	$data=['Sudipta','Sudip','Ram'];
    	return view('users',['users'=>$data]);
    }
}
