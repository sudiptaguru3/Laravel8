<table border="1">
	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($item->id); ?></td>
		<td><?php echo e($item->name); ?></td>
		<td><?php echo e($item->email); ?></td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH C:\xampp\htdocs\8\blogs\resources\views/list.blade.php ENDPATH**/ ?>