<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class Members extends Controller
{
    //
    function operations()
    {
    	// echo "Code willbe here";
    	// return DB::table('members')->get();
    	// return view('list',['data'=>$data]);
    	// return DB::table('members')
    	// ->where('id',2)
    	// ->get();
    	// return (array)DB::table('members')->find(2);
    	// return DB::table('members')->count();
    	return DB::table('members')
    	->where('id',1)->delete();
    	// ->where('id',1)
    	// ->insert([
    	// ->update([
    	// 	'name'=>'Sudipta Guru',
    	// 	'email'=>'sudipta@mail.com'
    	// ]);
    }
}
