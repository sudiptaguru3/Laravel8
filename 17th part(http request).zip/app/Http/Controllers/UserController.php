<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
// use Illuminate\Support\Facades\Http;
class UserController extends Controller
{
	// function index()
	// {
	// 	echo "api call will be here";
	// }
	function testRequest(Request $req)
	{
		// echo "form submitted";
		return $req->input();
	}
}
