<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserrController extends Controller
{
    //
    function loadView()
    {
    	// return view("userr",["userr"=>'Sudipta']);
    	return view("userr",["names"=>['Sudipta','Ram','Shyam']]);
    }
}
