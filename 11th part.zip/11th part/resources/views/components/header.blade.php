<div>
	<h1>Header Component</h1>
    <!-- Simplicity is the consequence of refined emotions. - Jean D'Alembert -->
</div>