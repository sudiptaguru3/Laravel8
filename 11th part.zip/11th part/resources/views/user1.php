<h2>{{10+20}}</h2>
<h2>Hello, {{$userr}} </h2>
<x-header />
<h1>User Page</h1>