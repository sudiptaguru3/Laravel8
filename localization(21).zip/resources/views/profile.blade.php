<h1>{{__('profile.welcome')}}</h1>
<a href="">{{__('profile.about')}}</a>
<a href="">{{__('profile.list')}}</a>
<a href="">{{__('profile.contact')}}</a>
