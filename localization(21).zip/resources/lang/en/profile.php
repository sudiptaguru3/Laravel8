<?php
return  [
	'welcome'=>'Welcome to Profile',
	'about'=>'about',
	'list'=>'list',
	'contact'=>'contact'
]
?>