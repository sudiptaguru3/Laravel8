<?php
return  [
	'welcome'=>'프로필에 오신 것을 환영합니다',
	'about'=>'약',
	'list'=>'명부
',
	'contact'=>'접촉
'
]
?>