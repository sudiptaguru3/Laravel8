<h1><?php echo e(__('profile.welcome')); ?></h1>
<a href=""><?php echo e(__('profile.about')); ?></a>
<a href=""><?php echo e(__('profile.list')); ?></a>
<a href=""><?php echo e(__('profile.contact')); ?></a>
<?php /**PATH C:\xampp\htdocs\8\blogs\resources\views/profile.blade.php ENDPATH**/ ?>